<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<!-- Sidebar Configuration, follow the link to modify-->
<?php require_once "./components/menu.php" ?>


<div class="content">

    <?php require_once "./components/project.php" ?>

    <div class="slideshow col-lg-12 col-md-12 col-sm-12">
        <div class="slider col-lg-12 col-md-12 col-sm-12">
            <br>
            <figure>
                <img src="images/Banner/banner1.jpg" alt>
                <img src="images/Banner/banner2.jpg" alt>
                <img src="images/Banner/banner3.jpg" alt>
                <img src="images/Banner/banner4.jpg" alt>
                <img src="images/Banner/banner5.jpg" alt>
                <img src="images/Banner/banner6.jpg" alt>
                <img src="images/Banner/banner7.jpg" alt>
                <img src="images/Banner/offroad.jpg" alt>
            </figure>
        </div>
    </div>


    <div class="content col-lg-12 col-md-12 col-sm-12">

        <div class="gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <!-- Linha 1-->
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-lg-3 col-md-3 col-sm-3">
                            <a href="product1" class="fh5co-card-item">
                                <figure>
                                    <img src="images/Banner/amarracao.jpg">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Amarração de Carga</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-3">
                            <a href="product2" class="fh5co-card-item">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Banner/elevacao.jpg">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Elevação de Cargas</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-3">
                            <a href="product3" class="fh5co-card-item">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/AcessoriosSider.jpg">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Acessórios</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        
                        <div class="col-lg-3 col-md-3 col-sm-3">
                            <a href="product4" class="fh5co-card-item">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Banner/offroad.jpg">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Off Road</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="diferenciais col-lg-12 col-md-12 col-sm-12">


        <h2>Porque escolher a Brasil Comercial?</h2>


        <div class="col-lg-6 col-md-6 col-sm-6">
            <a><img src="images/SocialMidia/strong.png" width=50px;></a> &nbsp;
            <h3>Produtos resistentes</h3>
            <p>Todos os nossos produtos são testados e aprovados nos mais altos padrões de qualidade.
                Todos são extremamente resistentes e garantirão uma grande longevidade da sua
                compra.</p>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-6">
            <a><img src="images/SocialMidia/price.png" width=50px;></a> &nbsp;
            <h3>Preço X Qualidade</h3>
            <p>Qualidade é imprescindível, e ter um preço competitivo faz com que tenhamos o melhor custo x benefício. Desenvolvemos, neste mercado uma relação de valor alto a um custo baixo; todo nosso esforço é nessa direção.</p>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-6">
            <a><img src="images/SocialMidia/star.png" width=50px;></a> &nbsp;
            <h3>Atendimento Personalizado</h3>
            <p>Trabalhamos com a atenção dirigida para satisfazermos as necessidades dos nossos clientes e atender o mercado que nos propusemos,
                para que obtenham o melhor produto, com inovação e alta tecnologia.
                Estudamos muito, e nos comprometemos a entregar o melhor resultado. O cliente tem a ideia, nós entendemos e a executamos.</p>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-6">
            <a><img src="images/SocialMidia/delivery.png" width=50px;></a> &nbsp;
            <h3>Entrega eficiente</h3>
            <p>Vamos além do preço e qualidade. Também temos foco em garantir que todos os produtos sejam entregues no menor tempo possível.
                Afinal, a sua empresa não pode parar, vamos ajudá-los com isso!.</p>
        </div>
    </div>
    <!-- Footer Configuration, follow the link to modify-->
    <?php require_once "./components/footer.php" ?>