<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<!-- Sidebar Configuration, follow the link to modify-->
<?php require_once "./components/menu.php" ?>


<div class="content">

    <?php require_once "./components/project.php" ?>
    <div class="Location_About col-lg-12 col-md-12 col-sm-12">
        <h2>A Empresa</h2>

    </div>

    <div class="Empresa col-lg-12 col-md-12 col-sm-12">
        <h2>Brasil Comercial</h2>

        <p> &nbsp;&nbsp;&nbsp; A Brasil Comercial é uma empresa do ramo de fitas para Amarração e Elevação de Cargas. Acreditamos que qualidade e excelência são parte fundamental de um negócio; sendo assim, trabalhamos para que nossos clientes possuam o melhor equipamento para auxiliá-los em suas necessidades. Nossos produtos são produzidos com o melhor componente do mundo: o <strong>Amor ao Trabalho</strong>.
        </p>
    </div>

    <div class="content col-lg-12 col-md-12 col-sm-12">

        <div class="gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <!-- Linha 1-->
                    <div class="col-lg-12 col-md-12 col-sm-12">

                        <div class="col-lg-4 col-md-4 col-sm-4 box">
                            </a><img src="images/SocialMidia/mission.png" width=50px;>
                            <h2>Missão</h2>
                            <p> &nbsp;&nbsp;&nbsp; Oferecer soluções em Movimentação, Amarração e Elevação de Cargas.
                            </p>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 box">
                            <a href=""></a><img src="images/SocialMidia/eye.png" width=50px;></a>
                            <h2>Visão</h2>
                            <p> &nbsp;&nbsp;&nbsp;Ser a melhor opção do mercado, com resultados satisfatórios e seguros, com clientes satisfeitos e
                                tendo prazer de nos indicar aos amigos e parceiros.</p>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 box">
                            <a href=""></a><img src="images/SocialMidia/star.png" width=50px;></a>
                            <h2>Valores</h2>
                            <p> &nbsp;&nbsp;&nbsp; Parceria, integridade, respeito, responsabilidade, agilidade, eficácia e eficiência,
                                seguros de um bom atendimento e qualidade dos produtos.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Footer Configuration, follow the link to modify-->
    <?php require_once "./components/footer2.php" ?>