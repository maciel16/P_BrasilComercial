<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<!-- Sidebar Configuration, follow the link to modify-->
<?php require_once "./components/menu.php" ?>


<div class="content">

    <?php require_once "./components/project.php" ?>

    <div class="Location_About col-lg-12 col-md-12 col-sm-12">
        <h2>Entre em Contato Conosco</h2>

    </div>

    <div class="form col-lg-12 col-md-12 col-sm-12">
        <br>
        <div clss="contact">

            <div id="contactform" class="col-lg-12 col-md-12 col-sm-12">
                <!-- modify this form HTML and place wherever you want your form -->

                <?php
                if ($_POST) {
                    //Carrega as classes do PHPMailer
                    include("./phpmailer/class.phpmailer.php");
                    include("./phpmailer/class.smtp.php");

                    //envia o e-mail para o visitante do site
                    $mailDestino = $_POST['Email'];
                    $nome = $_POST['Name'];
                    $mensagem = "Olá, $_POST[Name] <br/>
                    Recebemos sua mensagem, obrigado pelo seu contato!<br/>
                    Sua solicitação foi encaminhada para o departamento responsável, retornaremos o mais breve possível.<br/>
                    <br/> Por favor não responda esse email!
                    <br/>
                    Atenciosamente, 
                    Gestão Brasil Comercial.";
                    $assunto = "Brasil Comercial - Não Responder";
                    include("./envio.php");

                    //envia o e-mail para o administrador do site
                    $mailDestino = 'vendas1@brasilcomercial.com.br';
                    $nome = 'Contato Site';
                    $assunto = "Novo Formulario Recebido: $_POST[Subject]";
                    $mensagem = "Recebemos uma nova mensagem no site. <br/>
                    <br/>
                    Segue abaixo informações...
                    <br/>
                    <br/>
                    <strong>Nome:</strong> $_POST[Name]<br/>
                    <strong>E-mail:</strong> $_POST[Email]<br/>
                    <strong>Telefone:</strong> $_POST[Phone]<br/>
                    <strong>Como conheceu a Empresa:</strong> $_POST[HowKUS]<br/>
                    <strong>Assunto:</strong> $_POST[Subject]<br/>
                    <strong>Mensagem:</strong> $_POST[Message]";
                    include("./envio.php");
                    if ($mail->Send()) // Envia o email
                    {
                        echo "<script>window.location='default';alert('Email Enviado!');</script>";
                    }
                }
                ?>


                <form method="POST" name="formContato">
                    <fieldset class="form-group">
                        <label for="name">Nome: </label>
                        <br>
                        <input id="name" name="Name" class="form-control" required placeholder="Nome Completo" value="" required />
                    </fieldset>

                    <fieldset class="form-group">
                        <label>Email:</label>
                        <br>
                        <input type="email" name="Email" class="form-control" value="" required placeholder="seuemail@gmail.com" />
                        <span id="email-invalid" style="visibility:hidden">
                            Por favor, informe um E-mail valido.</span>
                    </fieldset>

                    <fieldset class="form-group">
                        <label>Telefone:</label>
                        <br>
                        <input type="text" name="Phone" class="form-control">
                    </fieldset>

                    <fieldset class="form-group">
                        <label>Como nos conheceu?</label>
                        <br>
                        <select id="list" name="HowKUS" placeholder="Internet" required class="form-control" required>
                            <option value="Redes Sociais">Redes Sociais</option>
                            <option value="Internet">Internet</option>
                            <option value="Busca no Google">Busca no Google</option>
                            <option value="Outros">Outros</option>
                        </select>
                    </fieldset>

                    <fieldset class="form-group">
                        <label for="subject">Assunto: </label>
                        <br>
                        <input id="subject" name="Subject" class="form-control" required placeholder="Assunto" value="Orçamento" required />
                    </fieldset>

                    <fieldset class="form-group">
                        <label for="message">Mensagem: </label>
                        <br>
                        <textarea id="message" name="Message" class="form-control" required rows="10" placeholder="Digite aqui" required></textarea>
                    </fieldset>

                    <fieldset class="form-group">
                        <button type="submit" class="button-success pure-button button-xlarge"> Enviar</button>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer Configuration, follow the link to modify-->
    <?php require_once "./components/footer.php" ?>