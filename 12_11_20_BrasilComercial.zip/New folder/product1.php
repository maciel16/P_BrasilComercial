<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<!-- Sidebar Configuration, follow the link to modify-->
<?php require_once "./components/menu.php" ?>


<div class="content">
    <?php require_once "./components/project.php" ?>
    <div class="Location_Product col-lg-12 col-md-12 col-sm-12">
        <h2>Amarração</h2>

    </div>

    <div class="content col-lg-12 col-md-12 col-sm-12">

        <div class="gtco-section">
            <div class="gtco-container">
                <div class="row">

                    <!-- Linha 1-->
                    <div class="col-lg-12 col-md-12 col-sm-12">

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Amarracao/CatracasMoveis.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Amarracao/CatracasMoveis.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Móveis</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Amarracao/catacra_fixas.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Amarracao/catacra_fixas.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Fixas </h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Amarracao/AmarracaoTenda.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Amarracao/AmarracaoTenda.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Conjunto de Amarração para Tendas</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                    </div>

                    <!-- Linha 2-->
                    <div class="col-lg-12 col-md-12 col-sm-12">

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Amarracao/Amarracao35mm2t.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Amarracao/Amarracao35mm2t.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Conjunto de Amarração 35mm 2t </h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Amarracao/Amarracao3t.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Amarracao/Amarracao3t.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Conjunto de Amarração 3t </h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Amarracao/Amarracao5t.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Amarracao/Amarracao5t.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Conjunto de Amarração 5t</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Footer Configuration, follow the link to modify-->
    <?php require_once "./components/footer2.php" ?>