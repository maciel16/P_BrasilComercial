<nav class="navbar navbar-expand-sm bg navbar col-lg-12 col-md-12 col-sm-12">
  &nbsp;
  &nbsp;

  <div class="logo col-lg-1 col-md-1 col-sm-1">
    <a href="default"><img src="images/icon/BC.png"> </a>
  </div>
  &nbsp;
  &nbsp;

  <!-- Links -->
  <ul class="navbar-nav col-lg-6 col-md-6 col-sm-6">
    <li class="nav-item col-lg-3 col-md-3 col-sm-3">
      <a class="nav-link" href="default">Início</a>
    </li>
    &nbsp;
    <li class="nav-item col-lg-3 col-md-3 col-sm-3">
      <a class="nav-link" href="about">Empresa</a>
    </li>
    &nbsp;
    <!-- Dropdown -->
    <li class="nav-item dropdown col-lg-3 col-md-3 col-sm-3">
      <a class="nav-link" href="#" id="navbardrop" data-toggle="dropdown">
        Produtos
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="product3">Acessórios</a>
        <a class="dropdown-item" href="product1">Amarração de Cargas</a>
        <a class="dropdown-item" href="product2">Elevação de Cargas</a>
        <a class="dropdown-item" href="product4">Off Road</a>
      </div>
    </li>
    &nbsp;
    <li class="nav-item col-lg-3 col-md-3 col-sm-3">
      <a class="nav-link" href="contact">Contato</a>
    </li>
  </ul>

  <div class="col-lg-4 col-md-4 col-sm-4 contato_top">
    <div class="col-lg-12 col-md-12 col-sm-12 ">
      &nbsp;
      <a href="tel:+551933044559"><img src="images/SocialMidia/phone.png" width=20;> +55 19 3304-4559</a> &nbsp;
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12">
      &nbsp;
      <a href="https://api.whatsapp.com/send?phone=5519992948959"><img src="images/SocialMidia/whatsapp.png" width=20px;>+55 19 99294-8959</a> &nbsp;
    </div>
  </div>
</nav>