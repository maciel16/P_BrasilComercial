<div class="Contato col-lg-12 col-md-12 col-sm-12">


    <div class="TelefoneEmail col-lg-5 col-md-5 col-sm-5">
        <h4>Entre em Contato</h4>
        <a href="tel:+551933044559"><strong>Telefone: </strong> +55 19 3304-4559</a>
        <br>
        <a href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=vendas1@brasilcomercial.com.br "><strong>Email
                : </strong>vendas1@brasilcomercial.com.br </a>

        <h4>Siga-nos nas nossas redes sociais</h4>
        <a href="https://www.instagram.com/brcomamericana/?hl=pt-br"><img src="images/SocialMidia/insta.png" width=50px;></a> &nbsp;
        <a href="https://www.facebook.com/Brasil-Comercial-113847193765404"> <img src="images/SocialMidia/fb.png" width=50px;></a> &nbsp;
        <a href="https://www.linkedin.com/company/brasil-comercial-equipamentos"><img src="images/SocialMidia/linkedin.png" width=50px;></a> &nbsp;
        <a href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=vendas1@brasilcomercial.com.br"><img src="images/SocialMidia/mail.png" width=50px;></a> &nbsp;
        <a href="https://api.whatsapp.com/send?phone=5519992948959"><img src="images/SocialMidia/whatsapp.png" width=50px;></a> &nbsp;
        <p></p>
        <br>

    </div>


    <div class="Endereco col-lg-3 col-md-3 col-sm-3">
        <h4>Endereço</h4>
        <a href="https://www.google.com.br/maps/place/R.+Fortunata+Isaura+Salvador,+174+-+Jardim+Terram%C3%A9rica+II,+Americana+-+SP/@-22.7647921,-47.3549583,17z/data=!3m1!4b1!4m5!3m4!1s0x94c8995d1144f51b:0xea361f5939acae54!8m2!3d-22.7647971!4d-47.3527696">
            <strong>Rua:</strong> Fortunata Isaura Salvador, N° 174 <br>
            <strong>Bairro:</strong> Jd. Terramérica III<br>
            <strong>Cidade:</strong> Americana – SP<br>
            <strong>CEP:</strong> 13468-871<br>
        </a>
        <br>

    </div>


    <div class="Mapa col-lg-3 col-md-3 col-sm-3">
        <h4>Google Maps</h4>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3679.015874679811!2d-47.35495828556388!3d-22.764792138541555!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8995d1144f51b%3A0xea361f5939acae54!2sR.%20Fortunata%20Isaura%20Salvador%2C%20174%20-%20Jardim%20Terram%C3%A9rica%20II%2C%20Americana%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1590601686121!5m2!1spt-BR!2sbr" width="90%" height="50%" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        <br>

    </div>

</div>

<div class="footer col-lg-12 col-md-12 col-sm-12">
    <br>
    <p> &copy; BrasilComercial <?php echo date("Y"); ?>/ Desinged by JMITServices </p>
</div>
<br>
<br>
<!-- jQuery CDN -->
<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<!-- Bootstrap Js CDN -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<!-- Botton Top -->
<script type="text/javascript" src="js/bttop.js"></script>
<!-- Side Bar -->
<script type="text/javascript" src="js/sidebar.js"></script>

<!-- Magnific Popup -->
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/magnific-popup-options.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>


</body>

</html>