<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="description=" content="Serviços de Desenvolvimento de Sistemas, Manutenção de Computadores e Design">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <title>Brasil Comercial - Cintas para Movimentação,Amarração e Elevação de Cargas, Equipamentos e Acessários </title>
    <link rel="shortcut icon" type="image/x-icon" href="images/logo/favicon.ico">

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <!-- Button Top CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,900,900i" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/topbt.css" rel="stylesheet">
    <link href="css/column.css" rel="stylesheet">
    <link href="css/menu.css" rel="stylesheet">
    <link href="css/index.css" rel="stylesheet">
    <link href="css/about.css" rel="stylesheet">
    <link href="css/products.css" rel="stylesheet">
    <link href="css/contact.css" rel="stylesheet">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="css/magnific-popup.css">
</head>


<body>
<a id="button"></a>