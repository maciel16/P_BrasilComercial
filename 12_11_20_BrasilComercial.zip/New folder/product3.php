<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<!-- Sidebar Configuration, follow the link to modify-->
<?php require_once "./components/menu.php" ?>


<div class="content">
    <div class="Project col-lg-12 col-md-12 col-sm-12">
        <?php require_once "./components/project.php" ?>

    </div>
    <div class="Location_Product col-lg-12 col-md-12 col-sm-12">
        <h2>Acessórios</h2>

    </div>

    <div class="content col-lg-12 col-md-12 col-sm-12">

        <div class="gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <!-- Linha 1-->
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/Acessorios.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/Acessorios.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Acessórios Diversos</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/AcessoriosSider.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/AcessoriosSider.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Acessórios para Sider</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/catacra_fixas50mm.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/catacra_fixas50mm.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Fixas 50 mm </h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        

                    </div>

                    <!-- Linha 2-->
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/catacra_fixas100mm.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/catacra_fixas100mm.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Fixas 100 mm</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/CatracasMoveis25mm.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/CatracasMoveis25mm.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Móveis 25 mm</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/CatracasMoveis35mm.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/CatracasMoveis35mm.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Móveis 35 mm </h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        

                    </div>

                    <!-- Linha 3-->
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/CatracasMoveis50mm3t.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/CatracasMoveis50mm3t.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Móveis 50 mm</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/CatracasMoveis100mm5t.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/CatracasMoveis100mm5t.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Catracas Móveis 100 mm</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Acessorios/Manilha.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Acessorios/Manilha.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Manilhas </h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        

                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Footer Configuration, follow the link to modify-->
    <?php require_once "./components/footer2.php" ?>