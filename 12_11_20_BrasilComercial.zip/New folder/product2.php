<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<!-- Sidebar Configuration, follow the link to modify-->
<?php require_once "./components/menu.php" ?>


<div class="content">
    <?php require_once "./components/project.php" ?>
    <div class="Location_Product col-lg-12 col-md-12 col-sm-12">
        <h2>Elevação</h2>

    </div>

    <div class="content col-lg-12 col-md-12 col-sm-12">

        <div class="gtco-section">
            <div class="gtco-container">
                <div class="row">
                    <!-- Linha 1-->
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/arraste_3t.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/arraste_3t.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Conjuntos de Arraste</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/arraste_anzol.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/arraste_anzol.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Conjuntos de Arraste em Anzol</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/Cinta_band_tapete.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/Cinta_band_tapete.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Cinta Band / Tapete </h2>
                                    </div>
                                </div>
                            </a>
                        </div>



                    </div>

                    <!-- Linha 2-->
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/CintaSling.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/CintaSling.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Cintas Sling</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/CintaSlingF_S_5_1.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/CintaSlingF_S_5_1.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Cintas Sling F.S. 5:1 </h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/CintaSling7_1.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/CintaSling7_1.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Cintas Sling 7:1</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                    </div>

                    <!-- Linha 3-->

                    <div class="col-lg-12 col-md-12 col-sm-12">

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/guincheiro_cegonheiro.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/guincheiro_cegonheiro.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Conjunto Guincheiro e Cegonheiro</h2>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <a href="images/Portifolio/Elevacao/grab_leg2pernas.jpg" class="fh5co-card-item image-popup">
                                <figure>
                                    <div class="overlay"><i class="ti-plus"></i></div>
                                    <img src="images/Portifolio/Elevacao/grab_leg2pernas.jpg" alt="Image" class="img-responsive">
                                </figure>
                                <div class="fh5co-text">
                                    <div class="fh5co-text">
                                        <h2>Grab/Leg 2/3/4 Pernas</h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer2.php" ?>