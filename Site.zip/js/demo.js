$(".pc01_lab").each(function() {
    var lab = this.innerHTML;
    this.innerHTML = "01";
});

$(".pc01_id").each(function() {
    var id = this.innerHTML;
    this.innerHTML = "PC0101";
});

$(".pc01_status").each(function() {
    var status = this.innerHTML;
    this.innerHTML = "Ativo";
});

$(".pc01_ms").each(function() {
    var ms = this.innerHTML;
    this.innerHTML = "10";
});