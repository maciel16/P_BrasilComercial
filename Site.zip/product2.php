<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "./components/sidebar.php" ?>

    <div id="content">
        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="index.php">| Início</a>
                            <a>> Produtos</a>
                            <a href="produtct2.php">> Elevação</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>
        <div class="Project col-lg-12 col-md-12 col-sm-12">
            <h2>Desenvolvemos projetos, e personalizamos o seu produto!</h2>

        </div>
        <div class="Location_About col-lg-12 col-md-12 col-sm-12">
            <h2>Elevação</h2>

        </div>

        <div id="ContentAbout3" class="col-lg-12 col-md-12 col-sm-12">

            <div class="gtco-section">
                <div class="gtco-container">
                    <div class="row">
                        <!-- Linha 1-->
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/AcessoriosLinhaG8.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/AcessoriosLinhaG8.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Acessórios linha Grau 8</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/CintasdeElevacaoSling51.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/CintasdeElevacaoSling51.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas Elevação PES</h2>
                                            <p>Modelo Sling F.S. 5:1</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/CintasElevacaoSLING71.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/CintasElevacaoSLING71.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas Elevação PES</h2>
                                            <p>Modelo Sling F.S. 7:1</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/CintasElevacaoGRABLEG41jpeg.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/CintasElevacaoGRABLEG41jpeg.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas Elevação PES</h2>
                                            <p>Modelo Grab / LES F.S. 4:1</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- Linha 2-->
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/CintaElevacao RING.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/CintaElevacao RING.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas Elevação PES</h2>
                                            <p>Modelo Anel / Ring F.S. 5:1</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/CintaElevacaoANELRING71 .jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/CintaElevacaoANELRING71 .jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas Elevação PES</h2>
                                            <p>Modelo Anel / Ring F.S. 7:1</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/CintaElevacaoFLATSTEEL41.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/CintaElevacaoFLATSTEEL41.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas Elevação PES</h2>
                                            <p>Modelo Flat / Steal F.S. 4:1</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Elevacao/CintaElevacaoBANDTAPETE51(Branca).jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Elevacao/CintaElevacaoBANDTAPETE51(Branca).jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas Elevação PES</h2>
                                            <p>Modelo Band / Tapete F.S. 5:1 - Branca</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Configuration, follow the link to modify-->
            <?php require_once "./components/footer2.php" ?>