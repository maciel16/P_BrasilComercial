<?php 
// Modelo baseado no site: https://blog.invettor.com.br/phpmailer-gmail-outros-provedores/
 $mail = new phpmailer();
 $mail->IsSMTP(); 
 $mail->CharSet = 'UTF-8';
 //$mail->True --- Informa se a mensagem foi enviada com sucesso;
 $mail->Host = "smtp.gmail.com"; // Servidor SMTP
 $mail->SMTPSecure = "tls"; // conexão segura com TLS
 $mail->Port = 587; 
 $mail->SMTPAuth = true; // Caso o servidor SMTP precise de autenticação
 $mail->Username = "maciel16.contact@gmail.com"; // SMTP username
 $mail->Password = "91028799"; // SMTP password
 $mail->From = "maciel16.contact@gmail.com"; // From
 $mail->FromName = "Maciel Contato" ; // Nome de quem envia o email
 $mail->AddAddress($mailDestino, $nome); // Email e nome de quem receberá //Responder
 $mail->WordWrap = 50; // Definir quebra de linha
 $mail->IsHTML = true ; // Enviar como HTML
 $mail->Subject = $assunto ; // Assunto
 $mail->Body = '<br/>' . $mensagem . '<br/>' ; //Corpo da mensagem caso seja HTML
 $mail->AltBody = "$mensagem" ; //PlainText, para caso quem receber o email não aceite o corpo HTML

if(!$mail->Send()) // Envia o email
 { 
 echo "Erro no envio da mensagem";
 } 
?>