<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "./components/sidebar.php" ?>

    <div id="content">
        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-6 col-md-6 col-sm-6">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="index.php">| Início</a>
                            <a>> Produtos</a>
                            <a href="produtct1.php">> Amarração</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>
        <div class="Project col-lg-12 col-md-12 col-sm-12">
            <h2>Desenvolvemos projetos, e personalizamos o seu produto!</h2>

        </div>
        <div class="Location_About col-lg-12 col-md-12 col-sm-12">
            <h2>Amarração</h2>

        </div>

        <div id="ContentAbout3" class="col-lg-12 col-md-12 col-sm-12">

            <div class="gtco-section">
                <div class="gtco-container">
                    <div class="row">
                        <!-- Linha 1-->
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/CatracaFixa50mm.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/CatracaFixa50mm.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Catraca Fixa 50 miilimetros</h2>
                                            <p>Cintas 3 & 5 toneladas</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/ConjuntoGuincheiro.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/ConjuntoGuincheiro.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Conjunto Guincheiro</h2>
                                            <p>Cintas 3 & 5 toneladas</p>
                                            <br>
                                            <br>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/ConjuntoCegonheiro.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/ConjuntoCegonheiro.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Conjunto Cegonheiro</h2>
                                            <p>3 & 5 toneladas</p>
                                            <br>
                                            <br>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/Catraca35mm.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/Catraca35mm.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Catraca 35 milimetros</h2>
                                            <p>2 toneladas - Gancho “J” ou “S” nas extremidades</p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <!-- Linha 2-->
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/Catraca25mm.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/Catraca25mm.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Catraca 25 milimetros</h2>
                                            <p>1 tonelada - Gancho “S” ou “Mosquetão” nas extremidades</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/ConjuntodeArraste.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/ConjuntodeArraste.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Conjuntos de Arraste</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/CatracasMoveis.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/CatracasMoveis.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Catracas Móveis</h2>
                                            <br>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/FivelaRabicho.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/FivelaRabicho.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Fivelas Rabicho e Central Lock</h2>
                                            <p>Acessórios para Carroceria Sider</p>
                                            <br>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
        
                        <!-- Linha 3-->
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            
                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/CatracasFixas.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/CatracasFixas.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Catracas Fixas</h2>
                                            <br>
                                            <br>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/ConjuntodeAmarracao.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/ConjuntodeAmarracao.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Conjunto Amarração</h2>
                                            <p>Cinta 5 toneladas - Catraca Móvel</p>
                                            <br>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <a href="images/Portifolio/Amarracao/ConjuntodeAmarracao5.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Amarracao/ConjuntodeAmarracao5.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Conjunto Amarração</h2>
                                            <p>Cinta 5 toneladas - Catraca Móvel</p>
                                            <br>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer2.php" ?>