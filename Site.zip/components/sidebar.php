<nav id="sidebar">
    <div class="sidebar-header">
        <a href="default.php" >Brasil Comercial</a>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="default.php">Início</a>
            <a href="about.php">Empresa</a>
            <a href="#Produtos" data-toggle="collapse" aria-expanded="false">Produtos </a>
            <ul class="collapse list-unstyled" id="Produtos">
                <li><a href="product1.php">Amarração de Cargas</a></li>
                <li><a href="product2.php">Elevação de Cargas</a></li>
                <li><a href="product3.php">Off Road / Fora da Estrada</a></li>
            </ul>
            <a href="contact.php">Contato</a>
        </li>
    </ul>
    <ul class="list-unstyled CTAs">
        <li><a href="index.php" class="article">Página Inicial</a></li>
    </ul>
</nav>