<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "./components/sidebar.php" ?>

    <div id="content">
        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-3 col-md-3 col-sm-3">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="index.php">| Início</a>
                            <a href="contact.php">> Contato</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div class="Project col-lg-12 col-md-12 col-sm-12">
            <h2>Desenvolvemos projetos, e personalizamos o seu produto!</h2>

        </div>

        <div class="Location_About col-lg-12 col-md-12 col-sm-12">
            <h2>Entre em Contato Conosco</h2>

        </div>

        <div id="form" class="col-lg-12 col-md-12 col-sm-12">
            <br>
            <div id="contact">

                <div id="contactform" class="col-lg-12 col-md-12 col-sm-12">
                    <!-- modify this form HTML and place wherever you want your form -->

                    <?php
                    if ($_POST) {
                        //Carrega as classes do PHPMailer
                        include("./phpmailer/class.phpmailer.php");
                        include("./phpmailer/class.smtp.php");

                        //envia o e-mail para o visitante do site
                        $mailDestino = $_POST['Email'];
                        $nome = $_POST['Name'];
                        $mensagem = "Olá, $_POST[Name] <br/>
                    Recebemos sua mensagem!<br/>
                    Assim que possível retornaremos o contato.<br/>
                    <br/>
                    Atenciosamente";
                        $assunto = "Obrigado pelo seu contato!";
                        include("./envio.php");

                        //envia o e-mail para o administrador do site
                        $mailDestino = 'maciel16.contact@gmail.com';
                        $nome = 'Maciel Contato';
                        $assunto = "Nova Mensagem: $_POST[Subject]";
                        $mensagem = "Recebemos uma nova mensagem no site. <br/>
                    <br/>
                    Segue abaixo informações...
                    <br/>
                    <br/>
                    <strong>Nome:</strong> $_POST[Name]<br/>
                    <strong>E-mail:</strong> $_POST[Email]<br/>
                    <strong>Telefone:</strong> $_POST[CellPhone]<br/>
                    <strong>Como conheceu a Empresa:</strong> $_POST[HowKUS]<br/>
                    <strong>Assunto:</strong> $_POST[Subject]<br/>
                    <strong>Mensagem:</strong> $_POST[Message]";
                        include("./envio.php");
                        header("location: index.php");
                    }
                    ?>


                    <form method="POST" name="formContato">
                        <fieldset class="form-group">
                            <label for="name">Nome: </label>
                            <br>
                            <input id="name" name="Name" class="form-control" placeholder="Nome Completo" value="" required />
                        </fieldset>

                        <fieldset class="form-group">
                            <label>Email:</label>
                            <br>
                            <input type="email" name="Email" class="form-control" value="" required placeholder="seuemail@gmail.com" />
                            <span id="email-invalid" style="visibility:hidden">
                                Por favor, informe um E-mail valido.</span>
                        </fieldset>

                        <fieldset class="form-group">
                            <label>Telefone:</label>
                            <br>
                            <input type="text" name="CellPhone" class="form-control" onkeypress="$(this).mask('(00) 00000-0000')" placeholder="(00) 00000-0000">
                        </fieldset>

                        <fieldset class="form-group">
                            <label>Como nos conheceu?</label>
                            <br>
                            <select id="list" name="HowKUS" placeholder="Internet" class="form-control" required>
                                <option value="Redes Sociais">Redes Sociais</option>
                                <option value="Internet">Internet</option>
                                <option value="Busca no Google">Busca no Google</option>
                                <option value="Outros">Outros</option>
                            </select>
                        </fieldset>

                        <fieldset class="form-group">
                            <label for="subject">Assunto: </label>
                            <br>
                            <input id="subject" name="Subject" class="form-control" placeholder="Assunto" value="Orçamento" required />
                        </fieldset>

                        <fieldset class="form-group">
                            <label for="message">Mensagem: </label>
                            <br>
                            <textarea id="message" name="Message" class="form-control" rows="10" placeholder="Digite aqui" required></textarea>
                        </fieldset>

                        <fieldset class="form-group">
                            <button type="submit" class="button-success pure-button button-xlarge"> Enviar</button>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>

        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer.php" ?>