<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "./components/sidebar.php" ?>

    <div id="content">
        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-3 col-md-3 col-sm-3">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <a href="index.php">| Início</a>
                            <a href="about.php">> Empresa</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>
        <div class="Project col-lg-12 col-md-12 col-sm-12">
            <h2>Desenvolvemos projetos, e personalizamos o seu produto!</h2>

        </div>
        <div class="Location_About col-lg-12 col-md-12 col-sm-12">
            <h2>A Empresa</h2>

        </div>

        <div class="Empresa col-lg-12 col-md-12 col-sm-12">
            <h2>Brasil Comercial</h2>

            <p> &nbsp;&nbsp;&nbsp; A Brasil Comercial é uma empresa do ramo de fitas para Amarração e Elevação de Cargas.
                Acreditamos que qualidade e excelência são parte fundamental de um negócio,
                sendo assim trabalhamos para que nossos clientes possuão o melhor equipamento para auxilia-los em suas necessidades.
                Nosso produtos são produzidos com o melhor componente do mundo, o <strong>Amor ao Trabalho</strong>.
            </p>
        </div>



        <div class="mvv col-lg-12 col-md-12 col-sm-12">
            <div class="about2 col-lg-12 col-md-12 col-sm-12">
                <a href=""></a><img src="images/SocialMidia/mission.png" width=50px;></a>
                <h2>Missão</h2>
                <p> &nbsp;&nbsp;&nbsp; Oferecer soluções em Movimentação, Amarração e Elevação de Cargas.
                </p>

            </div>
        </div>

        <div class="mvv col-lg-12 col-md-12 col-sm-12">
            <div class="about2 col-lg-12 col-md-12 col-sm-12">
                <a href=""></a><img src="images/SocialMidia/eye.png" width=50px;></a>
                <h2>Visão</h2>
                <p> &nbsp;&nbsp;&nbsp;Ser a melhor opção do mercado, com resultados satisfatórios e seguros, com clientes satisfeitos e 
                    tendo prazer de nos indicar aos amigos e parceiros.</p>
            </div>
        </div>

        <div class="mvv col-lg-12 col-md-12 col-sm-12">
            <div class="about2 col-lg-12 col-md-12 col-sm-12">
                <a href=""></a><img src="images/SocialMidia/star.png" width=50px;></a>
                <h2>Valores</h2>
                <p> &nbsp;&nbsp;&nbsp; Parceria, integridade, respeito, responsabilidade, agilidade, eficácia e eficiência, 
                    seguros de um bom atendimento e qualidade dos produtos.</p>


            </div>
        </div>
        <div class="mvv col-lg-12 col-md-12 col-sm-12">
            <div class="about2 col-lg-12 col-md-12 col-sm-12">
                <a href=""></a><img src="images/SocialMidia/target.png" width=50px;></a>
                <h2>Objetivo</h2>
                <p> &nbsp;&nbsp;&nbsp; Continuar crescendo de forma consciente. Dedicando o nosso trabalho para total satisfação dos nossos clientes.</p>


            </div>
        </div>
        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer2.php" ?>