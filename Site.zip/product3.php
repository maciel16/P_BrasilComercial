<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "./components/sidebar.php" ?>

    <div id="content">
        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-5 col-md-5 col-sm-5">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="index.php">| Início</a>
                            <a>> Produtos</a>
                            <a href="produtct3.php">> Off Road</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>
        <div class="Project col-lg-12 col-md-12 col-sm-12">
            <h2>Desenvolvemos projetos, e personalizamos o seu produto!</h2>

        </div>
        <div class="Location_About col-lg-12 col-md-12 col-sm-12">
            <h2>Off Road</h2>

        </div>

        <div id="ContentAbout3" class="col-lg-12 col-md-12 col-sm-12">

            <div class="gtco-section">
                <div class="gtco-container">
                    <div class="row">
                        <!-- Linha 1-->
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <a href="images/Portifolio/Road/CintasPES.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Road/CintasPES.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Cintas PES</h2>
                                            <p>Reboque Off Road</p>
                                        </div>
                                    </div>
                                </a>
                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-4">
                                <a href="images/Portifolio/Road/ManilhaeAcessorios.jpeg" class="fh5co-card-item image-popup">
                                    <figure>
                                        <div class="overlay"><i class="ti-plus"></i></div>
                                        <img src="images/Portifolio/Road/ManilhaeAcessorios.jpeg" alt="Image" class="img-responsive">
                                    </figure>
                                    <div class="fh5co-text">
                                        <div class="fh5co-text">
                                            <h2>Manilhas e Acessórios Off Road</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer.php" ?>