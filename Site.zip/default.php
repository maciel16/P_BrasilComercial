<!-- Header Configuration, follow the link to modify-->
<?php require_once "./components/head.php" ?>

<div class="wrapper">

    <!-- Sidebar Configuration, follow the link to modify-->
    <?php require_once "./components/sidebar.php" ?>

    <div id="content">
        <div class="">
            <nav class="navbar navbar-default col-lg-12 col-md-12 col-sm-12 ">
                <div class="container-fluid col-lg-12 col-md-12 col-sm-12 ">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="navbar-btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse nav navbar-nav navbar-right col-lg-2 col-md-2 col-sm-2">
                        <div id="" class="col-lg-12 col-md-12 col-sm-12">
                            <a href="principal.php">| Início</a>
                        </div>
                    </div>
                </div>
            </nav>

        </div>

        <div class="Project col-lg-12 col-md-12 col-sm-12">
            <h2>Desenvolvemos projetos, e personalizamos o seu produto!</h2>

        </div>

        <div id="slideshow" class="col-lg-12 col-md-12 col-sm-12">
            <div id="slider" class="col-lg-12 col-md-12 col-sm-12">
                <br>
                <figure>
                    <img src="images/Portifolio/Amarracao/Catraca25mm.jpeg" alt>
                    <img src="images/Portifolio/Amarracao/Catraca35mm.jpeg" alt>
                    <img src="images/Portifolio/Road/CintasPES.jpeg" alt>
                    <img src="images/Portifolio/Amarracao/CatracaFixa50mm.jpeg" alt>
                    <img src="images/Portifolio/Amarracao/ConjuntodeAmarracao.jpeg" alt>
                    <img src="images/Portifolio/Elevacao/CintasdeElevacaoSling51.jpeg" alt>
                    <img src="images/Portifolio/Elevacao/AcessoriosLinhaG8.jpeg" alt>
                    <img src="images/Portifolio/Amarracao/CatracasMoveis.jpeg" alt>
                </figure>
            </div>
        </div>


        <div class="ContentP col-lg-12 col-md-12 col-sm-12">

            <div class="mvv col-lg-4 col-md-4 col-sm-4">
                <div class="about2 col-lg-12 col-md-12 col-sm-12">
                    <h2>Amarração de Carga </h2>
                    <p>&nbsp;&nbsp;&nbsp;Presilhas, Catracas, Cintas, Conjuntos Diversos, etc...
                        <br>
                        <br>
                        <br><a href="product1.php">Saiba mais...</a>
                    </p>
                </div>
            </div>
            <div class="mvv col-lg-4 col-md-4 col-sm-4">
                <div class="about2 col-lg-12 col-md-12 col-sm-12">
                    <h2>Elevação de Cargas</h2>
                    <p>&nbsp;&nbsp;&nbsp;Cintas de elevação em diversos modelos:<br>Sling, Anel/Ring, Grab/Leg, Steel, Band, Etc...
                        <br><a href="product2.php">Saiba mais...</a>
                    </p>
                </div>
            </div>
            <div class="mvv col-lg-4 col-md-4 col-sm-4">
                <div class="about2 col-lg-12 col-md-12 col-sm-12">
                    <h2>Off Road</h2>
                    <p>&nbsp;&nbsp;&nbsp;Cintas de Reboque Diversas, Acessários, Etc...
                        <br>
                        <br>
                        <br>
                        <br><a href="product3.php">Saiba mais...</a>
                    </p>
                </div>
            </div>
            <br>
            <br>
        </div>
        <br>
        <br>
        <div class="diferenciais col-lg-12 col-md-12 col-sm-12">


            <h2>Porque escolher a Brasil Comercial?</h2>


            <div class="col-lg-6 col-md-6 col-sm-6">
                <a><img src="images/SocialMidia/strong.png" width=50px;></a> &nbsp;
                <h3>Produtos resistentes</h3>
                <p>Todos os nossos produtos são testados e aprovados nos mais altos padrões de qualidade.
                    Todos são extremamente resistentes e garantirão uma grande longevidade da sua
                    compra.</p>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">
                <a><img src="images/SocialMidia/price.png" width=50px;></a> &nbsp;
                <h3>Preço X Qualidade</h3>
                <p>Qualidade é imprescindível, e ter um preço competitivo faz com que tenhamos o melhor custo x benefício.
                    Desenvolvemos neste mercado, uma relação de valor alto a um custo baixo, todo nosso esforço é nesta direção.</p>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">
                <a><img src="images/SocialMidia/star.png" width=50px;></a> &nbsp;
                <h3>Atendimento Personalizado</h3>
                <p>Trabalhamos com a atenção dirigida para satisfazermos as necessidades dos nossos clientes e atender o mercado que nos propusemos,
                    para que obtenham o melhor produto, com inovação e alta tecnologia.
                    Estudamos muito, e nos comprometemos a entregar o melhor resultado. O cliente tem a idéia, nós entendemos e a executamos.</p>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">
                <a><img src="images/SocialMidia/delivery.png" width=50px;></a> &nbsp;
                <h3>Entrega eficiente</h3>
                <p>Vamos além do preço e qualidade. Também temos foco em garantir que todos os produtos sejam entregues no menor tempo possível.
                    Afinal, a sua empresa não pode parar, os ajudamos com isso.</p>
            </div>
        </div>
        <!-- Footer Configuration, follow the link to modify-->
        <?php require_once "./components/footer.php" ?>