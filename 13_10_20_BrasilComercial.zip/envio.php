<?php 
// Modelo baseado no site: https://blog.invettor.com.br/phpmailer-gmail-outros-provedores/
 $mail = new phpmailer();
 $mail->IsSMTP(); 
 $mail->CharSet = 'UTF-8';
 $mail->Host = "smtp.hostinger.com.br"; // Servidor SMTP
 $mail->SMTPSecure = "tls"; // conexão segura com TLS
 $mail->Port = 587; 
 $mail->SMTPAuth = true; // Caso o servidor SMTP precise de autenticação
 $mail->Username = "contato@brasilcomercial.com.br"; // SMTP username
 $mail->Password = "Contato1"; // SMTP password
 $mail->From = "contato@brasilcomercial.com.br"; // From
 $mail->FromName = "Contato Brasil Comercial" ; // Nome de quem envia o email
 $mail->AddAddress($mailDestino, $nome); // Email e nome de quem receberá //Responder
 $mail->WordWrap = 50; // Definir quebra de linha
 $mail->IsHTML = true ; // Enviar como HTML
 $mail->Subject = $assunto ; // Assunto
 $mail->Body = '<br/>' . $mensagem . '<br/>' ; //Corpo da mensagem caso seja HTML
 $mail->AltBody = "$mensagem" ; //PlainText, para caso quem receber o email não aceite o corpo HTML

if(!$mail->Send()) // Envia o email
 { 
 echo "Erro no envio da mensagem";
 }
?>