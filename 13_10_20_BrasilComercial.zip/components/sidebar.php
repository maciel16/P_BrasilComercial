<nav id="sidebar">
    <div class="sidebar-header">
        <a href="default" >Brasil Comercial</a>
    </div>
    <ul class="list-unstyled components">
        <li>
            <a href="default">Início</a>
            <a href="about">Empresa</a>
            <a href="#Produtos" data-toggle="collapse" aria-expanded="false">Produtos </a>
            <ul class="collapse list-unstyled" id="Produtos">
                <li><a href="product1">Amarração de Cargas</a></li>
                <li><a href="product2">Elevação de Cargas</a></li>
                <li><a href="product3">Off Road / Fora da Estrada</a></li>
            </ul>
            <a href="contact">Contato</a>
        </li>
    </ul>
    <ul class="list-unstyled CTAs">
        <li><a href="default" class="article">Página Inicial</a></li>
    </ul>
</nav>